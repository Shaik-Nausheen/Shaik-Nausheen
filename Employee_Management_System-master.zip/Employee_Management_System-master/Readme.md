
# Employee Management System

## Overview of this project :

Employee management system is a sample web application which basically includes crud operations for adding/updating/deleting employees from a web page to the database .This project is a startup for building my interest in leaveraging python language and application development using python's open source packages and libraries.

### Technologies & packages used in this project :

Python , Flask , My-sql , Json-Pickle , render_template , Behave , Nose , Selenium , Unit-tests , Html .. etc

### IDE used :

1) Eclipse
2) My-sql

### Approaches :

I have used below approachess in this project

1) Test Driven Development
2) Behaviour Driven Development
3) Automation testing of an application using selenium in python language.
