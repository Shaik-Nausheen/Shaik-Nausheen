# Yadey-A-Social-Media-Web-App
To apply industrial best practices and create a fast, scalable and  secure web application. To learn and apply the knowledge of full  stack development in real life projects and to understand the  in-depth working of MERN Stack applications.
