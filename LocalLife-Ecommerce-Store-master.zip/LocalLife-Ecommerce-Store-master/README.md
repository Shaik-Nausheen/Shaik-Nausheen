# LocalLife-Ecommerce-Store
E-commerce Platform for Local Sellers
Local Life is an online e-commerce marketplace that connects shoppers with local stores and services.
Created a Python based full stack e-commerce store on Django and Postgres hosted on Heroku 
Automated testing with continuous integration using Travis CI & Selenium
![Screen Shot 2020-05-04 at 1 50 36 PM](https://user-images.githubusercontent.com/43662680/80996844-80371000-8e0e-11ea-9132-b1a8b6f546be.png)



### how to run 
![Screen Shot 2020-04-21 at 6 08 10 PM](https://user-images.githubusercontent.com/43662680/79918782-1aed2300-83fb-11ea-9001-b08762cf98c7.png)

Make a environment place the src folder in it 
From terminal cd to src folder
Run the command - python manage.py runserver
